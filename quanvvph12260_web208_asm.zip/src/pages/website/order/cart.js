import React from "react";
import { API } from "../../../config";
const CartPage = () => {
  let cart = localStorage.getItem("cart");
  cart = cart == null ? [] : JSON.parse(cart);
  let totalMoneny = 0;
  let tableConten = ``;
  if (cart.length > 0) {
    return (
      <section className="cart_area">
        <div className="container">
          <div className="cart_inner">
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">Product</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {cart.forEach((item, index) => {
                    console.log(item.name);
                    totalMoneny += item.quantity * item.price;
                    tableConten += (
                  <tr>
                    <td>
                      <div className="media">
                        <div className="d-flex">
                          
                        </div>
                        <div className="media-body">
                          <p>${item.name}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <h5>$ ${item.price}</h5>
                    </td>
                    <td>
                      <div className="product_count">
                        <input
                          type="text"
                          name="qty"
                          id="sst"
                          value="${item.quantity}"
                          maxLength={12}
                          defaultValue={1}
                          title="Quantity:"
                          className="input-text qty"
                        />
                      </div>
                    </td>
                    <td>
                      <h5>$ ${item.price * item.quantity}</h5>
                    </td>
                  </tr>);
                  })}
                  ${(tableConten += (
                  <tr>
                    <td></td>
                    <td></td>
                    <td>
                      <h5>Tổng thanh toán</h5>
                    </td>
                    <td>
                      <h5>${totalMoneny} ₫</h5>
                    </td>
                                    
                  </tr>))}
                  <tr className="bottom_button">
                    <td>
                      <a className="button">Update Cart</a>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr></tr>
                  <tr className="out_button_area">
                    <td className="d-none-l"></td>
                    <td className></td>
                    <td></td>
                    <td>
                      <div className="checkout_btn_inner d-flex align-items-center">
                        <a className="gray_btn">Shopping</a>
                        <a className="primary-btn ml-2">Proceed to checkout</a>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    );
  }else{
    return(
      <section className="blog-banner-area" id="category">
        <div className="container h-100">
          <div className="blog-banner">
            <div className="text-center">
              <h3>Chưa có sản phẩm nào trong giỏ hàng</h3>
              <nav aria-label="breadcrumb" className="banner-breadcrumb">
                <ol className="breadcrumb">
                  <a href="#" className="button button--active mt-3 mt-xl-4">Tiếp tục mua hàng</a>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </section>
    )
  }
};

export default CartPage;
