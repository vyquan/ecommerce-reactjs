import ProductAPI from "../api/productAPI";

const addToCart ={
    async render(productId){
         let cart = localStorage.getItem('cart') // them cart vào local S torgae
         cart = cart == null ? [] : JSON.parse(cart); // ép sang kiểu json . nếu có cart trả về kiểu Json còn k có trả về 1 mảng rỗng 
         const {data:product} = await  ProductAPI.get(productId) ;
        let existed  = cart.map(e =>  e._id).indexOf(productId)
        console.log(existed);
        if(existed == -1){
            product.quantity =1
            cart.push(product)
            console.log(cart);
            localStorage.setItem('cart',JSON.stringify(cart))
        }else{
            cart[existed].quantity +=1
            localStorage.setItem('cart',JSON.stringify(cart))
        }
        await this.updateToCartDisplay();
    },
    async updateToCartDisplay(){
            let cart = localStorage.getItem('cart');
            cart = cart == null ? [] : JSON.parse(cart);
            let toTalCart = 0
            if(cart.length > 0){
                cart.forEach(element=>{
                    toTalCart += element.quantity
                }) ;
            }else{
                // toTalCart =0
                console.log("ghszf");
            }
            document.querySelector('.total-cart-product').innerHTML = toTalCart
    }

}
export  default addToCart;