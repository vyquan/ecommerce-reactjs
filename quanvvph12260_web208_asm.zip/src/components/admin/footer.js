import React from "react";

const FooterAdmin = () => {
  return (
    <footer>

    </footer>
  )
};

export default FooterAdmin;
